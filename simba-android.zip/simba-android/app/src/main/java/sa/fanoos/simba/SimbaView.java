package sa.fanoos.simba;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

/**
 * جسم سمبا: يرسم أحد الاتجاهات العشرة، مع تحريك (تمايل، تمدد، دوران، قفز)
 * وتأثيرات صغيرة (قلوب، Zzz، صحن أكل).
 */
public class SimbaView extends View {
    public static final int FRONT = 0, FRONT_RIGHT = 1, RIGHT = 2, BACK_RIGHT = 3, BACK = 4,
            BACK_LEFT = 5, LEFT = 6, FRONT_LEFT = 7, TOP = 8, BOTTOM = 9, SLEEP = 10,
            SIT = 11, HAPPY = 12, STRETCH = 13, EATING = 14, JUMP = 15, LICK = 16;

    /** لكل اتجاه: الإطار 0 للوقوف، وما بعده إطارات المشي. */
    private static final int[][] RES = {
            {R.drawable.simba_front, R.drawable.w_f1, R.drawable.w_f2, R.drawable.w_f3, R.drawable.w_f2},
            {R.drawable.simba_front_right, R.drawable.w_fr1},
            {R.drawable.simba_right, R.drawable.w_r1, R.drawable.w_r2, R.drawable.w_r3,
                    R.drawable.w_r4, R.drawable.w_r5, R.drawable.w_r6},
            {R.drawable.simba_back_right, R.drawable.w_br1},
            {R.drawable.simba_back, R.drawable.w_b1, R.drawable.w_b2},
            {R.drawable.simba_back_left, R.drawable.w_bl1},
            {R.drawable.simba_left, R.drawable.w_l1, R.drawable.w_l2, R.drawable.w_l3,
                    R.drawable.w_l4, R.drawable.w_l5, R.drawable.w_l6},
            {R.drawable.simba_front_left, R.drawable.w_fl1},
            {R.drawable.simba_top},
            {R.drawable.simba_bottom},
            {R.drawable.simba_sleep},
            {R.drawable.p_sit}, {R.drawable.p_happy}, {R.drawable.p_stretch},
            {R.drawable.p_eating}, {R.drawable.p_jump}, {R.drawable.p_lick}};

    private final Bitmap[][] bmp = new Bitmap[RES.length][];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF dst = new RectF();
    private final int s, w, h;

    public int sprite = FRONT;
    /** مرحلة المشي: سالب = وقوف، وإلا رقم الإطار المتدرّج. */
    public float walkPhase = -1f;
    public float sx = 1f, sy = 1f, rot = 0f, offX = 0f, offY = 0f, alpha = 1f;
    public boolean zzz, bowl;
    public long heartsUntil;

    public SimbaView(Context c) {
        super(c);
        s = Ui.dp(c, 112);
        w = s;
        h = s + s / 4; // مساحة فوق القطة للتأثيرات
        for (int i = 0; i < RES.length; i++) {
            bmp[i] = new Bitmap[RES[i].length];
            for (int j = 0; j < RES[i].length; j++) {
                bmp[i][j] = BitmapFactory.decodeResource(c.getResources(), RES[i][j]);
            }
        }
        tp.setTextAlign(Paint.Align.CENTER);
    }

    public int widthPx() {
        return w;
    }

    public int heightPx() {
        return h;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        Bitmap[] set = bmp[Math.max(0, Math.min(RES.length - 1, sprite))];
        int idx = 0;
        if (walkPhase >= 0f && set.length > 1) idx = 1 + ((int) walkPhase) % (set.length - 1);
        Bitmap b = set[idx];
        if (b != null) {
            c.save();
            c.translate(offX, offY);
            c.rotate(rot, w / 2f, h);
            c.scale(sx, sy, w / 2f, h);
            p.setAlpha(Math.round(Math.max(0f, Math.min(1f, alpha)) * 255));
            dst.set(0, h - s, w, h);
            c.drawBitmap(b, null, dst, p);
            c.restore();
        }

        if (bowl) {
            float cx = w / 2f, cy = h - s * 0.1f;
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF3F7FC4);
            c.drawOval(cx - s * 0.26f, cy - s * 0.07f, cx + s * 0.26f, cy + s * 0.07f, p);
            p.setColor(0xFF8B5A2B);
            c.drawOval(cx - s * 0.2f, cy - s * 0.055f, cx + s * 0.2f, cy + s * 0.03f, p);
        }

        if (now < heartsUntil) {
            tp.setTextSize(s * 0.17f);
            for (int i = 0; i < 5; i++) {
                float t = ((now + i * 260L) % 1300L) / 1300f;
                float hx = w / 2f + (float) Math.sin(i * 2.1f + t * 6f) * 0.3f * s;
                float hy = h - s * 0.7f - t * s * 0.5f;
                tp.setColor(0xFFFF6B8A);
                tp.setAlpha(Math.round(255 * (1f - t)));
                c.drawText("♥", hx, hy, tp);
            }
        }

        if (zzz) {
            tp.setColor(0xFF4A6FA5);
            for (int i = 0; i < 3; i++) {
                float t = ((now + i * 700L) % 2100L) / 2100f;
                tp.setTextSize(s * (0.12f + 0.05f * i));
                tp.setAlpha(Math.round(255 * (1f - t)));
                float zx = w * 0.68f + i * s * 0.08f + (float) Math.sin(t * 6f) * s * 0.02f;
                float zy = h - s * 0.68f - t * s * 0.3f - i * s * 0.07f;
                c.drawText(i == 0 ? "z" : "Z", zx, zy, tp);
            }
        }
    }
}
