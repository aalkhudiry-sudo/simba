package sa.fanoos.simba;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Random;

/** خدمة تُبقي سمبا حيّة وعائمة فوق كل التطبيقات، وتدير سلوكها. */
public class SimbaService extends Service {
    public static SimbaService instance;

    private static final int IDLE = 0, WALK = 1, SLEEP = 2, EAT = 3, PET = 4, ALERT = 5, DRAG = 6,
            SIT = 7, GROOM = 8, STRETCH = 9;
    private static final long HUNGRY_FULL_MS = 6L * 3600 * 1000;

    private static final String[] PET_LINES = {"برررر 💗", "مياو! 😻", "كمّل كمّل 🥰", "حلو هالمسح 😽"};
    private static final String[] CHATTER = {"مياو~ 🐾", "أنا هنا معك 😸", "تبغى تلعب؟ اضغط علي!",
            "اشرب موية يا بطل 💧", "لا تنسى تريّح عيونك شوي 👀"};

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private WindowManager wm;
    private SimbaView cat;
    private WindowManager.LayoutParams lp;
    private TextView bubble;
    private WindowManager.LayoutParams blp;
    private boolean bubbleShown;
    private LinearLayout menu;
    private boolean menuShown;

    private int state = IDLE;
    private float x, y, tx, ty;
    private long lastTick, stateUntil, nextAction, nextHungerMsg, nextChatter, nextBatteryMsg;
    private int lastPlugged = -1;
    private boolean dragging, longPressed;
    private int screenW, screenH;
    private int lastLx = Integer.MIN_VALUE, lastLy = Integer.MIN_VALUE;

    private final Runnable hideBubble = this::removeBubble;
    private final Runnable hideMenuR = this::hideMenu;
    private final Runnable longPress = () -> {
        if (!dragging) {
            longPressed = true;
            showMenu();
        }
    };
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                update();
            } catch (RuntimeException ignored) {
                // لا نوقف الخدمة بسبب خطأ في إطار واحد
            }
            h.postDelayed(this, 33);
        }
    };

    private final BroadcastReceiver battery = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ? 1 : 0;
            int pct = level < 0 ? -1 : Math.round(level * 100f / Math.max(1, scale));
            long now = SystemClock.uptimeMillis();
            if (lastPlugged == 0 && plugged == 1) {
                celebrate("🔌 شكراً على الشحن! حسّيت بطاقة ✨");
            } else if (plugged == 0 && pct >= 0 && pct <= 20 && now > nextBatteryMsg) {
                nextBatteryMsg = now + 30L * 60 * 1000;
                say("بطاريتك " + pct + "٪ تقريباً.. أنا جوعانة مثل بطاريتك! 🔋", 9000);
            }
            lastPlugged = plugged;
        }
    };

    public static boolean isRunning() {
        return instance != null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        instance = this;
        wm = getSystemService(WindowManager.class);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;

        if (Store.getLong(this, Store.LAST_FED, 0) == 0) {
            Store.putLong(this, Store.LAST_FED, System.currentTimeMillis());
        }

        cat = new SimbaView(this);
        lp = new WindowManager.LayoutParams(cat.widthPx(), cat.heightPx(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        x = screenW - cat.widthPx() - Ui.dp(this, 8);
        y = screenH * 0.6f;
        applyPosition();
        cat.setOnTouchListener(new Touch());
        wm.addView(cat, lp);

        buildBubble();

        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(battery, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(battery, f);
        }

        long now = SystemClock.uptimeMillis();
        lastTick = now;
        nextAction = now + 4000;
        nextChatter = now + (20L + rnd.nextInt(20)) * 60 * 1000;
        h.post(tick);
        h.postDelayed(() -> celebrate("مرحبا يا " + Store.userName(this) + "! أنا سمبا 🐱"), 600);
    }

    private void startAsForeground() {
        Reminders.ensureChannels(this);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, SimbaService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, Reminders.CH_BUDDY)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("سمبا معك 🐱")
                .setContentText("اضغط لفتح الإعدادات")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_notif), "إيقاف سمبا", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        instance = null;
        h.removeCallbacksAndMessages(null);
        try {
            unregisterReceiver(battery);
        } catch (RuntimeException ignored) {
        }
        hideMenu();
        removeBubble();
        try {
            if (cat != null && cat.isAttachedToWindow()) wm.removeView(cat);
        } catch (RuntimeException ignored) {
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------ اللمس
    private class Touch implements View.OnTouchListener {
        private float sx, sy, ox, oy;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX();
                    sy = e.getRawY();
                    ox = x;
                    oy = y;
                    dragging = false;
                    longPressed = false;
                    h.postDelayed(longPress, 650);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (!dragging && Math.hypot(dx, dy) > Ui.dp(SimbaService.this, 8)) {
                        dragging = true;
                        h.removeCallbacks(longPress);
                        hideMenu();
                        state = DRAG;
                    }
                    if (dragging) {
                        x = clampX(ox + dx);
                        y = Math.max(0, Math.min(screenH - cat.heightPx() / 2f, oy + dy));
                        applyPosition();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    h.removeCallbacks(longPress);
                    if (dragging) {
                        state = IDLE;
                        nextAction = SystemClock.uptimeMillis() + 3000;
                    } else if (!longPressed && e.getActionMasked() == MotionEvent.ACTION_UP) {
                        pet();
                    }
                    dragging = false;
                    return true;
                default:
                    return false;
            }
        }
    }

    private float clampX(float v) {
        return Math.max(0, Math.min(screenW - cat.widthPx(), v));
    }

    private void applyPosition() {
        int nx = Math.round(x), ny = Math.round(y);
        if (nx == lastLx && ny == lastLy) return;
        lastLx = nx;
        lastLy = ny;
        lp.x = nx;
        lp.y = ny;
        if (cat != null && cat.isAttachedToWindow()) {
            wm.updateViewLayout(cat, lp);
            placeBubble();
        }
    }

    // ------------------------------------------------------------ السلوك
    private boolean isNight() {
        int hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return Store.getBool(this, Store.NIGHT_ON, true) && (hr >= 22 || hr < 6);
    }

    private int hungerPct() {
        long fed = Store.getLong(this, Store.LAST_FED, System.currentTimeMillis());
        long d = System.currentTimeMillis() - fed;
        return (int) Math.max(0, Math.min(100, d * 100 / HUNGRY_FULL_MS));
    }

    private float walkPhase;

    private int dirSprite(float dx, float dy) {
        double ang = Math.toDegrees(Math.atan2(dy, dx)); // 0 = يمين، 90 = أسفل
        int k = (int) Math.round(ang / 45.0);
        k = ((k % 8) + 8) % 8;
        int[] map = {SimbaView.RIGHT, SimbaView.FRONT_RIGHT, SimbaView.FRONT, SimbaView.FRONT_LEFT,
                SimbaView.LEFT, SimbaView.BACK_LEFT, SimbaView.BACK, SimbaView.BACK_RIGHT};
        return map[k];
    }

    private void update() {
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.1f, (now - lastTick) / 1000f);
        lastTick = now;
        float t = now / 1000f;

        int sprite = SimbaView.FRONT;
        float sx = 1f, sy = 1f, rot = 0f, offY = 0f, alpha = 1f;
        boolean zzz = false, bowl = false;
        if (state != WALK) walkPhase = 0f;
        float phase = state == WALK ? walkPhase : -1f;

        switch (state) {
            case DRAG:
                sprite = SimbaView.BOTTOM;
                rot = (float) Math.sin(t * 14) * 6f;
                break;

            case WALK: {
                float dx = tx - x, dy = ty - y;
                float dist = (float) Math.hypot(dx, dy);
                float step = Ui.dp(this, 80) * dt;
                if (dist <= step) {
                    x = tx;
                    y = ty;
                    state = IDLE;
                    nextAction = now + 3000 + rnd.nextInt(6000);
                } else {
                    x += dx / dist * step;
                    y += dy / dist * step;
                }
                sprite = dirSprite(dx, dy);
                walkPhase += dt * 9f; // ٩ إطارات في الثانية
                offY = -Math.abs((float) Math.sin(t * 9)) * Ui.dp(this, 2);
                break;
            }

            case SLEEP:
                sprite = SimbaView.SLEEP;
                sy = 1f + 0.025f * (float) Math.sin(t * 1.8); // تنفّس هادئ
                sx = 1f - 0.01f * (float) Math.sin(t * 1.8);
                zzz = true;
                if (now > stateUntil && !isNight()) {
                    state = STRETCH;
                    stateUntil = now + 3200;
                } else if (now > stateUntil) {
                    stateUntil = now + 20000;
                }
                break;

            case EAT:
                sprite = SimbaView.EATING;
                sx = 1f - 0.015f * (float) Math.sin(t * 7);
                sy = 1f + 0.02f * (float) Math.sin(t * 7);
                if (now > stateUntil) {
                    state = IDLE;
                    nextAction = now + 3000;
                    say("شبعت! شكراً 😸", 4000);
                }
                break;

            case PET:
                sprite = SimbaView.HAPPY;
                sy = 1f + 0.02f * (float) Math.sin(t * 9);
                sx = 1f - 0.012f * (float) Math.sin(t * 9);
                if (now > stateUntil) {
                    state = IDLE;
                    nextAction = now + 3000;
                }
                break;

            case SIT:
                sprite = SimbaView.SIT;
                sy = 1f + 0.015f * (float) Math.sin(t * 2.2);
                if (now > stateUntil) {
                    state = IDLE;
                    nextAction = now + 2000;
                }
                break;

            case GROOM:
                sprite = SimbaView.LICK;
                sy = 1f + 0.012f * (float) Math.sin(t * 6);
                rot = (float) Math.sin(t * 6) * 1.2f;
                if (now > stateUntil) {
                    state = IDLE;
                    nextAction = now + 2500;
                }
                break;

            case STRETCH:
                sprite = SimbaView.STRETCH;
                sy = 1f + 0.015f * (float) Math.sin(t * 3);
                if (now > stateUntil) {
                    state = IDLE;
                    nextAction = now + 2500;
                }
                break;

            case ALERT:
                sprite = SimbaView.JUMP;
                offY = -Math.abs((float) Math.sin(t * 7)) * Ui.dp(this, 14);
                if (now > stateUntil) {
                    state = IDLE;
                    nextAction = now + 3000;
                }
                break;

            default: { // IDLE
                int[] looks = {SimbaView.FRONT, SimbaView.FRONT_LEFT, SimbaView.FRONT,
                        SimbaView.FRONT_RIGHT};
                sprite = looks[((int) (t / 1.8f)) % looks.length];
                sy = 1f + 0.02f * (float) Math.sin(t * 2.4);
                sx = 1f - 0.01f * (float) Math.sin(t * 2.4);
                if (now > nextAction) chooseAction(now);
                break;
            }
        }

        if (isNight() && state != ALERT) alpha *= 0.88f;

        cat.walkPhase = phase;
        cat.sprite = sprite;
        cat.sx = sx;
        cat.sy = sy;
        cat.rot = rot;
        cat.offY = offY;
        cat.alpha = alpha;
        cat.zzz = zzz;
        cat.bowl = bowl;
        applyPosition();
        cat.invalidate();

        if (state == IDLE && now > nextChatter && !isNight()) {
            nextChatter = now + (20L + rnd.nextInt(25)) * 60 * 1000;
            say(CHATTER[rnd.nextInt(CHATTER.length)], 5000);
        }
    }

    private void chooseAction(long now) {
        if (isNight() && rnd.nextInt(100) < 60) {
            startSleep(25000 + rnd.nextInt(30000));
            return;
        }
        if (hungerPct() > 75 && now > nextHungerMsg) {
            nextHungerMsg = now + 10L * 60 * 1000;
            say("جوعانة 🥺 اضغط عليّ مطوّلاً واختر «أطعمها»", 7000);
        }
        int r = rnd.nextInt(100);
        boolean wander = Store.getBool(this, Store.WANDER_ON, true);
        if (r < 45 && wander) {
            startWalk();
        } else if (r < 55) {
            startSleep(15000 + rnd.nextInt(15000));
        } else if (r < 70) {
            state = GROOM;
            stateUntil = now + 4000;
        } else if (r < 80) {
            state = STRETCH;
            stateUntil = now + 3200;
        } else if (r < 92) {
            state = SIT;
            stateUntil = now + 6000 + rnd.nextInt(6000);
        } else {
            nextAction = now + 3000 + rnd.nextInt(5000);
        }
    }

    private void startWalk() {
        float minY = screenH * 0.4f, maxY = screenH - cat.heightPx() - Ui.dp(this, 60);
        for (int i = 0; i < 6; i++) {
            tx = rnd.nextFloat() * (screenW - cat.widthPx());
            ty = minY + rnd.nextFloat() * Math.max(1f, maxY - minY);
            if (Math.hypot(tx - x, ty - y) > Ui.dp(this, 70)) break;
        }
        state = WALK;
    }

    private void startSleep(long ms) {
        state = SLEEP;
        stateUntil = SystemClock.uptimeMillis() + ms;
    }

    private void pet() {
        long now = SystemClock.uptimeMillis();
        state = PET;
        stateUntil = now + 1800;
        cat.heartsUntil = now + 1800;
        Store.putLong(this, Store.AFFECTION, Store.getLong(this, Store.AFFECTION, 0) + 1);
        if (rnd.nextBoolean()) say(PET_LINES[rnd.nextInt(PET_LINES.length)], 2500);
    }

    private void feed() {
        Store.putLong(this, Store.LAST_FED, System.currentTimeMillis());
        state = EAT;
        stateUntil = SystemClock.uptimeMillis() + 4500;
    }

    public void celebrate(String text) {
        if (cat == null) return;
        long now = SystemClock.uptimeMillis();
        state = ALERT;
        stateUntil = now + 2500;
        say(text, 7000);
    }

    /** تنبيه تذكير: تقفز وتعرض النص مدة أطول. */
    public void alert(String text) {
        if (cat == null) return;
        state = ALERT;
        stateUntil = SystemClock.uptimeMillis() + 10000;
        say(text, 30000);
    }

    // ------------------------------------------------------------ الفقاعة
    private void buildBubble() {
        bubble = new TextView(this);
        bubble.setTextSize(15);
        bubble.setTextColor(Ui.INK);
        bubble.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        bubble.setMaxWidth(Ui.dp(this, 240));
        int pad = Ui.dp(this, 10);
        bubble.setPadding(pad + 2, pad, pad + 2, pad);
        bubble.setBackground(Ui.round(this, Ui.CREAM, 16, Ui.BROWN));
        bubble.setOnClickListener(v -> removeBubble());
        blp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        blp.gravity = Gravity.TOP | Gravity.START;
    }

    public void say(String text, long ms) {
        if (bubble == null || wm == null) return;
        bubble.setText(text);
        if (!bubbleShown) {
            try {
                wm.addView(bubble, blp);
                bubbleShown = true;
            } catch (RuntimeException e) {
                return;
            }
        }
        placeBubble();
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, ms);
    }

    private void placeBubble() {
        if (!bubbleShown) return;
        bubble.measure(View.MeasureSpec.makeMeasureSpec(Ui.dp(this, 240), View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int bw = bubble.getMeasuredWidth(), bh = bubble.getMeasuredHeight();
        blp.x = Math.max(Ui.dp(this, 4), Math.min(screenW - bw - Ui.dp(this, 4),
                Math.round(x) + cat.widthPx() / 2 - bw / 2));
        blp.y = Math.round(y) - bh + Ui.dp(this, 22);
        if (blp.y < 0) blp.y = Math.round(y) + cat.heightPx();
        try {
            wm.updateViewLayout(bubble, blp);
        } catch (RuntimeException ignored) {
        }
    }

    private void removeBubble() {
        if (bubbleShown) {
            try {
                wm.removeView(bubble);
            } catch (RuntimeException ignored) {
            }
            bubbleShown = false;
        }
    }

    // ------------------------------------------------------------ القائمة
    private void showMenu() {
        hideMenu();
        removeBubble();
        LinearLayout m = new LinearLayout(this) {
            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_OUTSIDE) hideMenu();
                return true;
            }
        };
        m.setOrientation(LinearLayout.VERTICAL);
        m.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        m.setBackground(Ui.round(this, Ui.CREAM, 16, Ui.BROWN));
        int pad = Ui.dp(this, 6);
        m.setPadding(pad, pad, pad, pad);

        addItem(m, "🍗 أطعمها", this::feed);
        addItem(m, "💤 نامي", () -> startSleep(30000));
        addItem(m, "⏰ تذكير جديد", this::openSettings);
        addItem(m, "⚙️ الإعدادات", this::openSettings);
        addItem(m, "⏹ إيقاف سمبا", () -> stopSelf());

        WindowManager.LayoutParams mp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        mp.gravity = Gravity.TOP | Gravity.START;
        m.measure(View.MeasureSpec.makeMeasureSpec(screenW, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(screenH, View.MeasureSpec.AT_MOST));
        int mw = m.getMeasuredWidth(), mh = m.getMeasuredHeight();
        mp.x = Math.max(Ui.dp(this, 4), Math.min(screenW - mw - Ui.dp(this, 4),
                Math.round(x) + cat.widthPx() / 2 - mw / 2));
        mp.y = Math.round(y) - mh + Ui.dp(this, 20);
        if (mp.y < Ui.dp(this, 24)) mp.y = Math.round(y) + cat.heightPx();
        try {
            wm.addView(m, mp);
            menu = m;
            menuShown = true;
            h.postDelayed(hideMenuR, 9000);
        } catch (RuntimeException ignored) {
        }
    }

    private void addItem(LinearLayout m, String label, Runnable action) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(16);
        tv.setTextColor(Ui.INK);
        int p = Ui.dp(this, 10);
        tv.setPadding(p * 2, p, p * 2, p);
        tv.setOnClickListener(v -> {
            hideMenu();
            action.run();
        });
        m.addView(tv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void hideMenu() {
        h.removeCallbacks(hideMenuR);
        if (menuShown && menu != null) {
            try {
                wm.removeView(menu);
            } catch (RuntimeException ignored) {
            }
        }
        menu = null;
        menuShown = false;
    }

    private void openSettings() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(i);
        } catch (RuntimeException ignored) {
        }
    }
}
