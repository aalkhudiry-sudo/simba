package sa.fanoos.simba;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

/** تخزين بسيط لإعدادات سمبا والتذكيرات وحالتها. */
public final class Store {
    public static final String USER_NAME = "user_name";
    public static final String WANDER_ON = "wander_on";
    public static final String NIGHT_ON = "night_on";
    public static final String LAST_FED = "last_fed";
    public static final String AFFECTION = "affection";
    public static final String REMINDERS = "reminders";

    public static final String DEFAULT_NAME = "عبد المحسن";

    private Store() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("simba", Context.MODE_PRIVATE);
    }

    public static String get(Context c, String k, String def) {
        return p(c).getString(k, def);
    }

    public static void put(Context c, String k, String v) {
        p(c).edit().putString(k, v).apply();
    }

    public static boolean getBool(Context c, String k, boolean def) {
        return p(c).getBoolean(k, def);
    }

    public static void putBool(Context c, String k, boolean v) {
        p(c).edit().putBoolean(k, v).apply();
    }

    public static long getLong(Context c, String k, long def) {
        return p(c).getLong(k, def);
    }

    public static void putLong(Context c, String k, long v) {
        p(c).edit().putLong(k, v).apply();
    }

    public static synchronized JSONArray arr(Context c, String k) {
        try {
            return new JSONArray(get(c, k, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    public static synchronized void saveArr(Context c, String k, JSONArray a) {
        p(c).edit().putString(k, a.toString()).commit();
    }

    public static String userName(Context c) {
        String n = get(c, USER_NAME, DEFAULT_NAME).trim();
        return n.isEmpty() ? DEFAULT_NAME : n;
    }
}
