package sa.fanoos.simba;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** شاشة سمبا: الأذونات، تشغيل وإيقاف، الإعدادات، والتذكيرات. */
public class MainActivity extends Activity {
    private EditText name, remText, remMinutes;
    private Button overlayBtn, alarmBtn, startBtn;
    private CheckBox wander, night;
    private LinearLayout remList;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Reminders.ensureChannels(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.CREAM);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int pad = Ui.dp(this, 20);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        TextView title = Ui.text(this, "🐱 سمبا", 30, Ui.BROWN, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(title, full());
        TextView sub = Ui.text(this, "قطتك الأليفة العائمة على الشاشة", 15, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(sub, full());

        startBtn = Ui.button(this, "", Ui.BROWN, 0xFFFFFFFF);
        startBtn.setTextSize(18);
        startBtn.setOnClickListener(v -> toggleCat());
        col.addView(startBtn, gap(full(), 18));

        section(col, "الأذونات");
        overlayBtn = Ui.button(this, "", Ui.ORANGE, Ui.INK);
        overlayBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        col.addView(overlayBtn, gap(full(), 6));
        alarmBtn = Ui.button(this, "", Ui.ORANGE, Ui.INK);
        alarmBtn.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        col.addView(alarmBtn, gap(full(), 6));

        section(col, "عنك وعن سمبا");
        name = field(col, "اسمك (تناديك به سمبا)", Store.userName(this));
        wander = new CheckBox(this);
        wander.setText("🚶 سمبا تتمشى على الشاشة");
        wander.setChecked(Store.getBool(this, Store.WANDER_ON, true));
        col.addView(wander, gap(full(), 10));
        night = new CheckBox(this);
        night.setText("🌙 تنام في الليل (من ١٠ مساءً إلى ٦ صباحاً)");
        night.setChecked(Store.getBool(this, Store.NIGHT_ON, true));
        col.addView(night, full());

        section(col, "⏰ تذكير جديد");
        remText = field(col, "نص التذكير", "");
        remMinutes = field(col, "بعد كم دقيقة؟", "10");
        remMinutes.setInputType(InputType.TYPE_CLASS_NUMBER);
        Button add = Ui.button(this, "➕ أضف التذكير", Ui.ORANGE, Ui.INK);
        add.setOnClickListener(v -> addReminder());
        col.addView(add, gap(full(), 10));
        remList = new LinearLayout(this);
        remList.setOrientation(LinearLayout.VERTICAL);
        col.addView(remList, gap(full(), 8));

        TextView credit = Ui.text(this,
                "© 2026 Fanoos Studio — Abdulmohsen Alkhudiry. All rights reserved.\nfanoos.studio.sa@gmail.com",
                12, Ui.MUTED, false);
        credit.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(credit, gap(full(), 30));

        setContentView(sv);
        Ui.edgeToEdge(this, sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    private void refresh() {
        boolean ov = Settings.canDrawOverlays(this);
        overlayBtn.setText(ov ? "✅ مسموح لسمبا تظهر فوق التطبيقات" : "اسمح لسمبا تظهر فوق التطبيقات");
        overlayBtn.setEnabled(!ov);
        boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || getSystemService(AlarmManager.class).canScheduleExactAlarms();
        alarmBtn.setText(exact ? "✅ التذكيرات في وقتها بالضبط" : "اسمح بالتذكير في الوقت المحدد بالضبط");
        alarmBtn.setEnabled(!exact);
        startBtn.setText(SimbaService.isRunning() ? "⏹ إيقاف سمبا" : "▶️ تشغيل سمبا");
        renderReminders();
    }

    private void save() {
        Store.put(this, Store.USER_NAME, name.getText().toString().trim());
        Store.putBool(this, Store.WANDER_ON, wander.isChecked());
        Store.putBool(this, Store.NIGHT_ON, night.isChecked());
    }

    private void toggleCat() {
        save();
        if (SimbaService.isRunning()) {
            stopService(new Intent(this, SimbaService.class));
            startBtn.postDelayed(this::refresh, 300);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح لسمبا تظهر فوق التطبيقات أولاً", Toast.LENGTH_LONG).show();
            overlayBtn.performClick();
            return;
        }
        startForegroundService(new Intent(this, SimbaService.class));
        startBtn.postDelayed(this::refresh, 500);
        moveTaskToBack(true);
    }

    // ------------------------------------------------------------ التذكيرات
    private void addReminder() {
        String text = remText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "اكتب نص التذكير أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        double min;
        try {
            min = Double.parseDouble(remMinutes.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "اكتب عدد الدقائق بالأرقام", Toast.LENGTH_SHORT).show();
            return;
        }
        if (min < 1) min = 1;
        try {
            Reminders.add(this, text, System.currentTimeMillis() + (long) (min * 60000));
        } catch (Exception e) {
            Toast.makeText(this, "تعذّر حفظ التذكير", Toast.LENGTH_SHORT).show();
            return;
        }
        remText.setText("");
        Toast.makeText(this, "تمام! بذكّرك 😸", Toast.LENGTH_SHORT).show();
        renderReminders();
    }

    private void renderReminders() {
        remList.removeAllViews();
        JSONArray a = Store.arr(this, Store.REMINDERS);
        SimpleDateFormat f = new SimpleDateFormat("EEE HH:mm", Locale.forLanguageTag("ar"));
        if (a.length() == 0) {
            remList.addView(Ui.text(this, "ما فيه تذكيرات حالياً", 14, Ui.MUTED, false));
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            final int id = o.optInt("id");
            final String text = o.optString("text");
            TextView tv = Ui.text(this, "⏰ " + f.format(new Date(o.optLong("due"))) + " — " + text,
                    15, Ui.INK, false);
            int p = Ui.dp(this, 10);
            tv.setPadding(p, p, p, p);
            tv.setBackground(Ui.round(this, 0xFFFFFFFF, 12, 0xFFE2CFB3));
            tv.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setMessage("حذف التذكير؟\n" + text)
                    .setPositiveButton("حذف", (d, w) -> {
                        Reminders.remove(this, id, true);
                        renderReminders();
                    })
                    .setNegativeButton("إلغاء", null)
                    .show());
            remList.addView(tv, gap(full(), 6));
        }
    }

    // ------------------------------------------------------------ مساعدات
    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams gap(LinearLayout.LayoutParams p, int topDp) {
        p.topMargin = Ui.dp(this, topDp);
        return p;
    }

    private void section(LinearLayout col, String s) {
        col.addView(Ui.text(this, s, 17, Ui.INK, true), gap(full(), 22));
    }

    private EditText field(LinearLayout col, String hint, String value) {
        col.addView(Ui.text(this, hint, 13, Ui.MUTED, false), gap(full(), 8));
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(15);
        e.setTextColor(Ui.INK);
        e.setBackground(Ui.round(this, 0xFFFFFFFF, 12, 0xFFE2CFB3));
        int p = Ui.dp(this, 10);
        e.setPadding(p, p, p, p);
        col.addView(e, gap(full(), 4));
        return e;
    }
}
