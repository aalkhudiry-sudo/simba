package sa.fanoos.simba;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** يستقبل وقت التذكير، ويعيد جدولة التذكيرات بعد إعادة تشغيل الجوال. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Reminders.rescheduleAll(c);
            return;
        }
        int id = intent.getIntExtra("id", 0);
        String text = intent.getStringExtra("text");
        if (text == null) text = "";
        Reminders.remove(c, id, false);
        Reminders.notify(c, id, text);
        SimbaService s = SimbaService.instance;
        if (s != null) s.alert("⏰ يا " + Store.userName(c) + "! تذكير: " + text);
    }
}
