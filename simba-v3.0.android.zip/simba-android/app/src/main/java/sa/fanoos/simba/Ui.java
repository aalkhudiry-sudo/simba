package sa.fanoos.simba;

import android.app.Activity;
import android.content.Context;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.TextView;

/** أدوات صغيرة لبناء الواجهة بدون مكتبات. */
public final class Ui {
    public static final int CREAM = 0xFFFFF8EC;
    public static final int BROWN = 0xFF7A4A23;
    public static final int ORANGE = 0xFFE9A55B;
    public static final int INK = 0xFF3B2A1A;
    public static final int MUTED = 0xFF8A7A6A;

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    public static GradientDrawable round(Context c, int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(dp(c, 2), strokeColor);
        return g;
    }

    public static Button button(Context c, String text, int bg, int fg) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(15);
        b.setBackground(round(c, bg, 14, 0));
        b.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        return b;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    /** يضبط ألوان أشرطة النظام، ويترك مسافة لها وللكيبورد في أندرويد 15+. */
    public static void edgeToEdge(Activity a, View root) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController ic = a.getWindow().getInsetsController();
            if (ic != null) {
                int flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                ic.setSystemBarsAppearance(flags, flags);
            }
        }
        if (Build.VERSION.SDK_INT >= 35) {
            final int l0 = root.getPaddingLeft(), t0 = root.getPaddingTop(),
                    r0 = root.getPaddingRight(), b0 = root.getPaddingBottom();
            root.setOnApplyWindowInsetsListener((v, in) -> {
                Insets s = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                v.setPadding(l0 + s.left, t0 + s.top, r0 + s.right, b0 + s.bottom);
                return in;
            });
        }
    }
}
